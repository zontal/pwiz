REM this is the script that was used to generate the .mzML files in this test
REM the .raw files are available at https://www.gs.washington.edu/~kaipot/share/ADH_CE.zip
c:msconvert.exe SS_01_FSN20357_2592_020321.raw --filter peakPicking --filter "scanTime [759,1654]" --filter "msLevel 1" --filter "mzWindow [400,750]" --outfile SS_01_ms1.mzML
c:msconvert.exe SS_01_FSN20357_2592_020321.raw --filter peakPicking --filter "scanTime [759,1654]" --filter "msLevel 2"  --outfile SS_01_ms2.mzML
c:msconvert.exe --merge --filter sortByScanTime SS_01_ms1.mzML SS_01_ms2.mzML --chromatogramFilter "index 999" -n --noindex --outfile SS_01_FSN20357_2592_020321.mzML
c:msconvert.exe SS_02_FSN20357_2592_020321.raw --filter peakPicking --filter "scanTime [759,1654]" --filter "msLevel 1" --filter "mzWindow [400,750]"

c:msconvert.exe SS_02_FSN20357_2592_020321.raw --filter peakPicking --filter "scanTime [759,1654]" --filter "msLevel 1" --filter "mzWindow [400,750]" --outfile SS_02_ms1.mzML
c:msconvert.exe SS_02_FSN20357_2592_020321.raw --filter peakPicking --filter "scanTime [759,1654]" --filter "msLevel 2"  --outfile SS_02_ms2.mzML
c:msconvert.exe --merge --filter sortByScanTime SS_02_ms1.mzML SS_02_ms2.mzML --chromatogramFilter "index 999" -n --noindex --outfile SS_02_FSN20357_2592_020321.mzML
